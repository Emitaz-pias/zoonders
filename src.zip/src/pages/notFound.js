import React from 'react'
import { Container } from "react-bootstrap";

const notFound = () => {
    return (
        <Container>
            notFound page
        </Container>
    )
}

export default notFound
